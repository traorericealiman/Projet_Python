Wireframe Mobil :

https://www.figma.com/file/dxwh0MadazAHAzZOcEdOAt/Untitled?type=design&node-id=0-1&mode=design&t=8WeCT1teFgiYJBDe-0

Wireframe Desktop : 

https://www.figma.com/file/3cvP4mYPArqzkeXh3xhP1U/Untitled?type=design&node-id=0-1&mode=design&t=L9bGoPUjOkzUU4Fy-0

Tableau Kanban :

https://trello.com/b/LOsL0avW/projet-python